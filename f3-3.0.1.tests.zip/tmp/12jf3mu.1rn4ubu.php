<p><?php echo $love; ?> Fat-Free!</p>
<p><?php echo Base::instance()->format($today,time()); ?></p>
<p><?php echo $tqbf; ?></p>
<p><?php echo $undefined; ?>
<?php $pi_val='3.141593'; ?>
<p><?php echo Base::instance()->format($pi,$pi_val); ?></p>
<p><?php echo Base::instance()->format($money,63950.25); ?></p>
<p><?php echo isset($extra)?$extra:''; ?></p>