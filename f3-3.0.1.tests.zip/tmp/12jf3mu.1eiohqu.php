<div>
<?php for ($i=0;$i<3;$i++): ?>
	<?php echo $this->render('templates/test7.htm',$this->mime,get_defined_vars()); ?>
<?php endfor; ?>
</div>
<?php echo 'Temporary variable preserved across includes'; ?>

