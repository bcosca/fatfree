<div>
	<?php foreach (($div?:array()) as $dkey=>$dval): ?>
	<p><span><?php echo $dkey; ?></span>
		<?php foreach (($dval?:array()) as $skey=>$sval): ?>
		<span><?php echo $skey; ?>: <?php echo $sval; ?></span>
		<?php endforeach; ?>
	</p>
	<?php endforeach; ?>
</div>