<?php echo Base::instance()->raw($foo); ?>
