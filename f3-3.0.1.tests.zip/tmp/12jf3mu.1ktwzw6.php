<?php foreach (($div?:array()) as $ikey=>$idiv): ?>
<div>
	<p><span><b><?php echo $ikey; ?></b></span></p>
	<p>
<?php $ctr=0; foreach (($idiv?:array()) as $ispan): $ctr++; ?>
		<span class="<?php echo ($ctr%2)?'odd':'even'; ?>"><?php echo $ispan; ?></span>
<?php endforeach; ?>
	</p>
</div>
<?php endforeach; ?>
