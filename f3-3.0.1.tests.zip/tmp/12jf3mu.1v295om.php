<?php if ($cond1): ?>
	
	<?php if ($cond2): ?>
		c1:T,c2:T
		<?php else: ?>c1:T,c2:F
	<?php endif; ?>
	
	<?php else: ?><?php echo $cond2?'c1:F,c2:T':'c1:F,c2:F'; ?>
<?php endif; ?>