<?php $foo=1+2; $bar=$foo+3; $baz='xyz'; ?>
<span><?php echo $foo; ?></span>
<span><?php echo $bar; ?></span>
<span><?php echo $baz; ?></span>
<?php $foo='array(1,3,5)'; ?>
<span><?php echo $foo; ?></span>
<?php $bar=array('a','b','c'); ?>
<?php for ($i=0;$i<count($bar);$i++): ?>
	<span><?php echo $bar[$i]; ?></span>
<?php endfor; ?>
<?php echo 'email@address.com'; ?>
