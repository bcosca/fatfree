<?php

return array(
	'extra'=>'{0,number,percent}'
);
