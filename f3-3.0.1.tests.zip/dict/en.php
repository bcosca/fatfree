<?php

return array(
	'love'=>'I love',
	'today'=>'Today is {0,date,long}',
	'tqbf'=>'The quick brown fox jumps over the lazy dog.',
	'undefined'=>'Undefined',
	'pi'=>'{0,number}',
	'money'=>'{0,number,currency}'
);
