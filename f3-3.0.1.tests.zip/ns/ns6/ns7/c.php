<?php

namespace NS\NS6\NS7;
class C {}
