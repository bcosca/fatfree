<?php

namespace NS\NS3\NS4;
class C {}
