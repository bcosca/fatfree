<?php

namespace NS\NS3\NS5;
class C {}
