<?php

namespace NS\NS3;
class C {}
