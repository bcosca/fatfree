<?php

namespace NS\NS1;
class C {}
