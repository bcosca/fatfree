<?php

namespace NS\NS2;
class C {}
