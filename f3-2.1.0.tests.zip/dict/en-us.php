<?php

return array(
	'love'=>'I love',
	'today'=>'Today is {0,date}',
	'tqbf'=>'The quick brown fox jumps over the lazy dog.'
);
