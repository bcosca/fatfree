<?php

return array(
	'love'=>'J\'aime',
	'today'=>'Aujourd\'hui, c\'est {0,date}',
	'tqbf'=>'Les naïfs ægithales hâtifs pondant à Noël où il gèle sont sûrs d\'être déçus et de voir leurs drôles d\'œufs abîmés.'
);
