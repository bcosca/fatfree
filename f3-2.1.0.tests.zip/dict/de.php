<?php

return array(
	'love'=>'Ich liebe',
	'today'=>'Heute ist {0,date}',
	'tqbf'=>'Im finsteren Jagdschloß am offenen Felsquellwasser patzte der affig-flatterhafte kauzig-höfliche Bäcker über seinem versifften kniffligen Xylophon.'
);
