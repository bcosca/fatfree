<?php

return array(
	'pi'=>'{0,number}',
	'money'=>'{0,number,currency}'
);
