<?php

return array(
	'love'=>'Me encanta',
	'today'=>'Hoy es {0,date}',
	'tqbf'=>'El pingüino Wenceslao hizo kilómetros bajo exhaustiva lluvia y frío, añoraba a su querido cachorro.'
);
