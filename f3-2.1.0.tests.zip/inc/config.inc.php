<?php

function home() {}

function func1() {}
function func2() {}
function func3() {}

class App {
	static function page404() {}
	static function temp() { echo 'shout!'; }
}

class Map {
	static function get() {}
	static function post() {}
	static function put() {}
}

?>
